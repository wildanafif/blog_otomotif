﻿$('document').ready(function () {
    $('.navbar-toggle').on('click', function () {
        $('.collapse').toggle();
    });
});

